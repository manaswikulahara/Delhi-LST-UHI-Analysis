// --- LST May-June 2022 ---
var delhi = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level1")
              .filter(ee.Filter.eq('ADM1_NAME', 'Delhi'));
Map.centerObject(delhi, 9);
Map.addLayer(delhi, {color: 'black'}, 'Delhi Boundary');

function getLST(year) {
  var start = ee.Date.fromYMD(year, 5, 1);
  var end = ee.Date.fromYMD(year, 6, 30);
  var collection = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
    .filterBounds(delhi)
    .filterDate(start, end)
    .filter(ee.Filter.lt('CLOUD_COVER', 10))
    .map(function(image) {
      var thermal = image.select('ST_B10').multiply(0.00341802).add(149.0).subtract(273.15);
      return thermal.rename('LST_C').copyProperties(image, image.propertyNames());
    });
  return collection.mean().clip(delhi).set('year', year);
}

var lst2022 = getLST(2022);
Map.addLayer(lst2022, {min: 20, max: 45, palette: ['blue', 'cyan', 'yellow', 'orange', 'red']}, 'LST May-June 2022');
Export.image.toDrive({
  image: lst2022,
  description: 'LST_Delhi_2022',
  folder: 'EarthEngine',
  fileNamePrefix: 'LST_Delhi_2022',
  region: delhi.geometry(),
  scale: 30,
  maxPixels: 1e13
});