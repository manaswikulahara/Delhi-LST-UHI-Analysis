// --- Combined UHI Map for 2022-2024 ---
var delhi = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level1")
              .filter(ee.Filter.eq('ADM1_NAME', 'Delhi'));
Map.centerObject(delhi, 9);

function getLST(year) {
  var start = ee.Date.fromYMD(year, 5, 1);
  var end = ee.Date.fromYMD(year, 6, 30);
  var collection = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
    .filterBounds(delhi).filterDate(start, end)
    .filter(ee.Filter.lt('CLOUD_COVER', 10))
    .map(function(image) {
      return image.select('ST_B10').multiply(0.00341802).add(149.0).subtract(273.15)
                  .rename('LST_C').copyProperties(image, image.propertyNames());
    });
  return collection.mean().clip(delhi).set('year', year);
}

var lst2022 = getLST(2022);
var lst2023 = getLST(2023);
var lst2024 = getLST(2024);
var vis = {min: 20, max: 45, palette: ['blue', 'cyan', 'yellow', 'orange', 'red']};

Map.addLayer(lst2022, vis, 'LST May-June 2022');
Map.addLayer(lst2023, vis, 'LST May-June 2023');
Map.addLayer(lst2024, vis, 'LST May-June 2024');