# Delhi LST & Urban Heat Island Analysis (2022–2024)

This repository contains GEE JavaScript code to extract and visualize mean Land Surface Temperature (LST) over Delhi during May–June 2022, 2023, and 2024, and compare Urban Heat Island effects.

## Files
- `1_LST_May_June_2022.js`: Mean LST for 2022
- `2_LST_May_June_2023.js`: Mean LST for 2023
- `3_LST_May_June_2024.js`: Mean LST for 2024
- `4_LST_UHI_Combined_2022_2024.js`: Visualization for all years
- `README.md`: Description and instructions

## Notes
- Uses Landsat 8 Collection 2, Level 2 (`ST_B10` band)
- Converts temperature to °C from Kelvin
- Cloud-masking using `QA_PIXEL`
- Output: Visual maps + exportable GeoTIFFs

---

Made by **Manaswi Kulahara**, M.Sc. Geoinformatics, TERI SAS