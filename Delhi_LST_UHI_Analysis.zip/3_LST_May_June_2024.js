// --- LST May-June 2024 ---
var delhiAOI = ee.FeatureCollection('projects/ee-manaswikulahara8/assets/Delhi_ward');
Map.centerObject(delhiAOI, 10);
var startDate = '2024-05-01';
var endDate = '2024-06-30';
var l8sr = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2');

function maskL8srClouds(image) {
  var qaPixel = image.select('QA_PIXEL');
  var mask = qaPixel.bitwiseAnd(1 << 3).eq(0).and(qaPixel.bitwiseAnd(1 << 5).eq(0));
  return image.updateMask(mask);
}

function applyScaleAndCelsius(image) {
  return image.select('ST_B10').multiply(0.00341802).add(149.0).subtract(273.15)
              .rename('LST_Celsius').copyProperties(image, ['system:time_start']);
}

var filteredL8 = l8sr.filterBounds(delhiAOI).filterDate(startDate, endDate)
                     .map(maskL8srClouds).map(applyScaleAndCelsius);
var meanLST = filteredL8.select('LST_Celsius').mean().clip(delhiAOI);

Map.addLayer(meanLST, {min: 25, max: 50, palette: ['blue', 'cyan', 'green', 'yellow', 'red']}, 'Mean LST Delhi (2024)');
Export.image.toDrive({
  image: meanLST,
  description: 'Delhi_LST_MayJun2024_Celsius_UTM43N',
  folder: 'GEE_Exports',
  fileNamePrefix: 'Delhi_LST_MayJun2024',
  scale: 30,
  region: delhiAOI.geometry(),
  crs: 'EPSG:32643',
  maxPixels: 1e10,
  fileFormat: 'GeoTIFF'
});